################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../can_analyzer/src/can_analyzer.c 

OBJS += \
./can_analyzer/src/can_analyzer.o 

C_DEPS += \
./can_analyzer/src/can_analyzer.d 


# Each subdirectory must supply rules for building sources it contributes
can_analyzer/src/%.o can_analyzer/src/%.su can_analyzer/src/%.cyclo: ../can_analyzer/src/%.c can_analyzer/src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F429xx -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../USB_DEVICE/App -I../USB_DEVICE/Target -I../Middlewares/ST/STM32_USB_Device_Library/Core/Inc -I../Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Inc -I"/home/mjayakumar/VVDN_BU_PROJECTS/CAN_ANALYZER/can_analyzer/inc" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-can_analyzer-2f-src

clean-can_analyzer-2f-src:
	-$(RM) ./can_analyzer/src/can_analyzer.cyclo ./can_analyzer/src/can_analyzer.d ./can_analyzer/src/can_analyzer.o ./can_analyzer/src/can_analyzer.su

.PHONY: clean-can_analyzer-2f-src

